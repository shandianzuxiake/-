#include "5509.h"
#include "util.h"
#include "math.h"

extern float uu[L],xxf[L],yy[L],yyh[L],ee[L],ssh[L],ww[L];
extern float Pu,mu;
extern float alpha;
extern unsigned int count_pro;

unsigned int n=0;
/*
void IDENTIFICATION()
{
    PC55XX_MCSP pMCBSP0 = (PC55XX_MCSP)C55XX_MSP0_ADDR;
    int left_m1,left_m2;
    int i,temp;    
   
        while (!ReadMask(pMCBSP0 -> spcr2, SPCR2_XRDY));	// �ȴ�McBSP0׼����        
        left_m2=Read(pMCBSP0->ddr2);        
        left_m1=Read(pMCBSP0->ddr1);    
        ///////////////////////////////////////////////////////////////////////////////////
          yy[0]=(float)left_m2;
          yy[0]=yy[0]/32768.0;                      
          uu[0]=uu[0]/32768.0;
                           
          //compute yyh which is convolution of ssh and xx         
          yyh[0]=0.0;
          for(i=0;i<L;i++) 
          {             
              yyh[0]=yyh[0]+ssh[i]*uu[i];
          }          
          //compute ee(n)          
          ee[0]=yy[0]-yyh[0];       
          //Update coefficients of ssh using LMS algorithm
          alpha=mu*ee[0];
          for(i=0;i<L;i++)
          {
              ssh[i]=ssh[i]+alpha*uu[i];
          }	   
          
          for(i=L-1;i>0;i--)
          {
              uu[i]=uu[i-1];
              yy[i]=yy[i-1];
              yyh[i]=yyh[i-1];
              ee[i]=ee[i-1];
          }
          
          temp=rand()-0x4000;
          uu[0]=(float)temp;
          left_m2=temp;
          left_m1=temp;
       ////////////////////////////////////////////////////////////////////////////
        
        Write(pMCBSP0->dxr2,left_m2);		// �����ݵ�McBSP0
        Write(pMCBSP0->dxr1,left_m1);		// ���������AIC23���
        count_pro++;     
}
*/

/*
void FEEDFORWARD_ANC()
{
    PC55XX_MCSP pMCBSP0 = (PC55XX_MCSP)C55XX_MSP0_ADDR;
    int left_m1,left_m2;
    int left_y1;
    int i;
    float temp;
        
   
        while (!ReadMask(pMCBSP0 -> spcr2, SPCR2_XRDY));	// �ȴ�McBSP0׼����
        left_m2=Read(pMCBSP0->ddr2);
        left_m1=Read(pMCBSP0->ddr1);      
        ////////////////////////////////////////////////////////////////////////////////
          ee[0]=(float)left_m2;
          ee[0]=ee[0]/32768.0;
          uu[0]=(float)left_m1;
          uu[0]=uu[0]/32768.0;
          
          //Compute yy which is convolution of ww and xx
          yy[0]=0.0;
          for(i=0;i<L;i++)
          {
            yy[0]= yy[0]+ww[i]*uu[i];
          }
          //Compute xxm1 which is convolution of ssh and xx
          xxf[0]=0.0;
          for(i=0;i<L;i++)
          {
            xxf[0]=xxf[0]+ssh[i]*uu[i];
          }  
          //Update coefficients of ww1 using LMS algorithm
          alpha=0.02*ee[0];  
          for(i=0;i<L;i++)
          {
            ww[i]=ww[i]-alpha*xxf[i];
          }
          //delay one Sample
          for(i=L-1;i>0;i--)
          {
            uu[i]=uu[i-1];
            xxf[i]=xxf[i-1];
            ee[i]=ee[i-1];
            yy[i]=yy[i-1];
          } 
          ////////////////////////////////////////////////////////////////////////////////
          temp=yy[0]*32768;
          if(temp>32768) temp=32768;
          else if(temp<-32767) temp=-32767;
          left_y1=(int)temp;

        ////////////////////////////////////////////////////////////////////////////////

        Write(pMCBSP0->dxr2,left_y1);		// �����ݵ�McBSP0
        Write(pMCBSP0->dxr1,left_y1);		// ���������AIC23���
        count_pro++;
}
*/