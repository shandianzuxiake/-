#include <csl.h>
#include <csl_i2c.h>
#include <stdio.h>
#include <stdlib.h>
#include <csl_pll.h>
#include <csl_mcbsp.h>
#include <math.h>
#include <csl_emif.h>
#include <csl_chip.h>
#include <csl_gpio.h>
#include "5509.h"
#include "util.h"
#include "math.h"

#define L	8
#define CODEC_ADDR 0x1A
#define PI	3.1415926

/**************************************************/

PLL_Config  myConfig      = {
  0,    //IAI: the PLL locks using the same process that was underway 
                //before the idle mode was entered
  1,    //IOB: If the PLL indicates a break in the phase lock, 
                //it switches to its bypass mode and restarts the PLL phase-locking 
                //sequence
  12,    //PLL multiply value; multiply 24 times
  1             //Divide by 2 PLL divide value; it can be either PLL divide value 
                //(when PLL is enabled), or Bypass-mode divide value
                //(PLL in bypass mode, if PLL multiply value is set to 1)
};
MCBSP_Config Mcbsptest;
/*McBSP set,we use mcbsp1 to send and recieve the data between DSP and AIC23*/
MCBSP_Config Mcbsp1Config = {
  MCBSP_SPCR1_RMK(
    MCBSP_SPCR1_DLB_OFF,                   /* DLB    = 0,��ֹ�Աջ���ʽ */
    MCBSP_SPCR1_RJUST_LZF,                 /* RJUST  = 2 */
    MCBSP_SPCR1_CLKSTP_DISABLE,            /* CLKSTP = 0 */
    MCBSP_SPCR1_DXENA_ON,                  /* DXENA  = 1 */
    0,                                     /* ABIS   = 0 */
    MCBSP_SPCR1_RINTM_RRDY,                /* RINTM  = 0 */
    0,                                     /* RSYNCER = 0 */
    MCBSP_SPCR1_RRST_DISABLE               /* RRST   = 0 */
   ),
    MCBSP_SPCR2_RMK(
    MCBSP_SPCR2_FREE_NO,                   /* FREE   = 0 */
    MCBSP_SPCR2_SOFT_NO,                   /* SOFT   = 0 */
    MCBSP_SPCR2_FRST_FSG,                  /* FRST   = 0 */
    MCBSP_SPCR2_GRST_CLKG,                 /* GRST   = 0 */
    MCBSP_SPCR2_XINTM_XRDY,                /* XINTM  = 0 */
    0,                                     /* XSYNCER = N/A */           
    MCBSP_SPCR2_XRST_DISABLE               /* XRST   = 0 */
   ),
   /*�������࣬�������ݳ���Ϊ16λ,ÿ��2������*/
  MCBSP_RCR1_RMK( 
  	MCBSP_RCR1_RFRLEN1_OF(1),              /* RFRLEN1 = 1 */
  	MCBSP_RCR1_RWDLEN1_16BIT               /* RWDLEN1 = 2 */
  ),
  MCBSP_RCR2_RMK(    
    MCBSP_RCR2_RPHASE_SINGLE,              /* RPHASE  = 0 */
    MCBSP_RCR2_RFRLEN2_OF(0),              /* RFRLEN2 = 0 */
    MCBSP_RCR2_RWDLEN2_8BIT,               /* RWDLEN2 = 0 */
    MCBSP_RCR2_RCOMPAND_MSB,               /* RCOMPAND = 0 */
    MCBSP_RCR2_RFIG_YES,                   /* RFIG    = 0 */
    MCBSP_RCR2_RDATDLY_1BIT                /* RDATDLY = 1 */
    ),  
   MCBSP_XCR1_RMK(    
    MCBSP_XCR1_XFRLEN1_OF(1),              /* XFRLEN1 = 1 */ 
    MCBSP_XCR1_XWDLEN1_16BIT               /* XWDLEN1 = 2 */
    
 ),   
 MCBSP_XCR2_RMK(   
    MCBSP_XCR2_XPHASE_SINGLE,              /* XPHASE  = 0 */
    MCBSP_XCR2_XFRLEN2_OF(0),              /* XFRLEN2 = 0 */
    MCBSP_XCR2_XWDLEN2_8BIT,               /* XWDLEN2 = 0 */
    MCBSP_XCR2_XCOMPAND_MSB,               /* XCOMPAND = 0 */
    MCBSP_XCR2_XFIG_YES,                   /* XFIG    = 0 */
    MCBSP_XCR2_XDATDLY_1BIT                /* XDATDLY = 1 */
  ),            
 MCBSP_SRGR1_DEFAULT,
 MCBSP_SRGR2_DEFAULT,  
 MCBSP_MCR1_DEFAULT,
 MCBSP_MCR2_DEFAULT, 
 MCBSP_PCR_RMK(
   MCBSP_PCR_IDLEEN_RESET,                 /* IDLEEN   = 0   */
   MCBSP_PCR_XIOEN_SP,                     /* XIOEN    = 0   */
   MCBSP_PCR_RIOEN_SP,                     /* RIOEN    = 0   */
   MCBSP_PCR_FSXM_EXTERNAL,                /* FSXM     = 0   */
   MCBSP_PCR_FSRM_EXTERNAL,                /* FSRM     = 0   */
   0,                                      /* DXSTAT = N/A   */
   MCBSP_PCR_CLKXM_INPUT,                  /* CLKXM    = 0   */
   MCBSP_PCR_CLKRM_INPUT,                  /* CLKRM    = 0   */
   MCBSP_PCR_SCLKME_NO,                    /* SCLKME   = 0   */
   MCBSP_PCR_FSXP_ACTIVEHIGH,              /* FSXP     = 0   */
   MCBSP_PCR_FSRP_ACTIVEHIGH,              /* FSRP     = 1   */
   MCBSP_PCR_CLKXP_FALLING,                /* CLKXP    = 1   */
   MCBSP_PCR_CLKRP_RISING                  /* CLKRP    = 1   */
 ),
 MCBSP_RCERA_DEFAULT, 
 MCBSP_RCERB_DEFAULT, 
 MCBSP_RCERC_DEFAULT, 
 MCBSP_RCERD_DEFAULT, 
 MCBSP_RCERE_DEFAULT, 
 MCBSP_RCERF_DEFAULT, 
 MCBSP_RCERG_DEFAULT, 
 MCBSP_RCERH_DEFAULT, 
 MCBSP_XCERA_DEFAULT,
 MCBSP_XCERB_DEFAULT,
 MCBSP_XCERC_DEFAULT,
 MCBSP_XCERD_DEFAULT,  
 MCBSP_XCERE_DEFAULT,
 MCBSP_XCERF_DEFAULT,  
 MCBSP_XCERG_DEFAULT,
 MCBSP_XCERH_DEFAULT
};     
/* This next struct shows how to use the I2C API */
/* Create and initialize an I2C initialization structure */
I2C_Setup I2Cinit = {
        0,              /* 7 bit address mode */
        0,         /* own address - don't care if master */
        84,            /* clkout value (Mhz)  */
        50,            /* a number between 10 and 400*/
        0,              /* number of bits/byte to be received or transmitted (8)*/
        0,              /* DLB mode on*/
        1               /* FREE mode of operation on*/
};

I2C_Config testI2C;


/*������Ƶ�ӿڸ�ʽ����
AIC23Ϊ��ģʽ������ΪDSPģʽ�����ݳ���16λ*/   
Uint16 digital_audio_inteface_format[2]={0x0e,0x53};
/*AIC23�Ĳ��������ã�������Ϊ44.1K*/
Uint16 sample_rate_control[2] = {0x10,0x23};
/*AIC23�Ĵ�����λ*/
Uint16 reset[2] ={0x1e,0x00};
/*AIC23�ڵ緽ʽ���ã����в��־����빤��״̬*/
Uint16 power_down_control[2] ={0x0c,0x03};
/*AIC23ģ����Ƶ�Ŀ���
DACʹ�ܣ�ADC����ѡ��ΪLine*/
Uint16 analog_aduio_path_control[2] ={0x08,0x10};
/*AIC23������Ƶͨ·�Ŀ���*/
Uint16 digital_audio_path_control[2] ={0x0a,0x05};
/*AIC23���ֽӿڵ�ʹ��*/
Uint16 digital_interface_activation[2] ={0x12,0x01};
/*AIC23��ͨ·��Ƶ����*/
Uint16 left_line_input_volume_control[2] ={0x00,0x17};
/*AIC23��ͨ·��Ƶ����*/
Uint16 right_line_input_volume_control[2] ={0x02,0x17};
/*AIC23������ͨ·��Ƶ����*/
Uint16 left_headphone_volume_control[2] ={0x05,0xFF};
/*AIC23������ͨ·��Ƶ����*/
Uint16 right_headphone_volume_control[2] = {0x07,0xFF};

/*����McBSP�ľ��*/
MCBSP_Handle hMcbsp;

Uint16 i2c_status;
/***************************************************/

/**/
void wait(unsigned int cycles);
void INTR_init( );
void TIMER_init( );

int TIME_flag;
int ANC_flag=0;
unsigned int count_timer,count_pro;
unsigned int ID_time=4000;
     int dn=0;
   int data[8];
   int din=0;
   //float error=0;
   float y,delta;
   float sum;
   int u=128; 

float uu[L],xxf[L],yy[L],yyh[L],ee[L],ssh[L],ww[L];
float Pu=0.0,mu=0.002;
float alpha;
	float dinf[8];
	float dataf[8];
	float wn[8];
	float error[8];
void delay(Uint32 kkk)
{
   while(kkk--);
}
void IDENTIFICATION()
{
    PC55XX_MCSP pMCBSP0 = (PC55XX_MCSP)C55XX_MSP0_ADDR;
    int left_m1,left_m2;
    int i,temp; 
    
    while (!MCBSP_rrdy(hMcbsp)){};
        //while (!ReadMask(pMCBSP0 -> spcr2, SPCR2_XRDY));	// �ȴ�McBSP0׼����
        left_m2=MCBSP_read16(hMcbsp);
        left_m1=MCBSP_read16(hMcbsp);    
   
        //while (!ReadMask(pMCBSP0 -> spcr2, SPCR2_XRDY));	// �ȴ�McBSP0׼����        
        //left_m2=Read(pMCBSP0->ddr2);        
        //left_m1=Read(pMCBSP0->ddr1);    
        
        ///////////////////////////////////////////////////////////////////////////////////
          yy[0]=(float)left_m2;
          yy[0]=yy[0]/32768.0;                      
          uu[0]=uu[0]/32768.0;
                           
          //compute yyh which is convolution of ssh and xx         
          yyh[0]=0.0;
          for(i=0;i<L;i++) 
          {             
              yyh[0]=yyh[0]+ssh[i]*uu[i];
          }          
          //compute ee(n)          
          ee[0]=yy[0]-yyh[0];       
          //Update coefficients of ssh using LMS algorithm
          alpha=mu*ee[0];
          for(i=0;i<L;i++)
          {
              ssh[i]=ssh[i]+alpha*uu[i];
          }	   
          
          for(i=L-1;i>0;i--)
          {
              uu[i]=uu[i-1];
              yy[i]=yy[i-1];
              yyh[i]=yyh[i-1];
              ee[i]=ee[i-1];
          }
          
          temp=rand()-0x4000;
          uu[0]=(float)temp;
          left_m2=temp;
          left_m1=temp;
       ////////////////////////////////////////////////////////////////////////////
        
        //Write(pMCBSP0->dxr2,left_m2);		// �����ݵ�McBSP0
        //Write(pMCBSP0->dxr1,left_m1);		// ���������AIC23���
        MCBSP_write16(hMcbsp,left_m1);
        count_pro++;     
}
void FEEDFORWARD_ANC()
{
    PC55XX_MCSP pMCBSP0 = (PC55XX_MCSP)C55XX_MSP0_ADDR;
    int left_m1,left_m2;
    int left_y1;
    int i;
    float temp;
	int flag;


        
   
        while (!MCBSP_rrdy(hMcbsp)){};
        //while (!ReadMask(pMCBSP0 -> spcr2, SPCR2_XRDY));	// �ȴ�McBSP0׼����
        //left_m2=Read(pMCBSP0->ddr2);
        //left_m1=Read(pMCBSP0->ddr1);   
        //while (!MCBSP_rrdy(hMcbsp)){};
        //while (!ReadMask(pMCBSP0 -> spcr2, SPCR2_XRDY));	// �ȴ�McBSP0׼����
        left_m1=MCBSP_read16(hMcbsp);
        //left_m1=rand(); 
        
        
        flag=1;
        //////////////////
        dn=left_m1*10;
      data[0]=rand()-0x4000;
	  din=data[0]+dn; 
	   dinf[0]=(float)din;
          dinf[0]=dinf[0]/32768.0;
          dataf[0]=(float)data[0];
          dataf[0]=dataf[0]/32768.0;
	  sum=0.0;
	  
	  
	  
	  
	  for(i=0;i<7;i++)
	  {
	      sum+=dataf[i]*wn[i];
	  }
	  y=sum;
	  error[0]=dinf[0]-y;
	  for(i=0;i<7;i++)
	  {
	      sum=error[0];
		  delta=sum*dataf[i];
		  wn[i]+=0.002*delta;
	  }
	  for(i=0;i<7;i++)
	  {
	      data[7-i]=data[6-i];
	      dataf[7-i]=dataf[6-i];
	      //error[7-i]=error[6-i];
	      //dinf[7-i]=dinf[6-i];
	  }
	  left_m2=error[0]*32768;
          if(left_m2>32768) left_m2=32768;
          else if(left_m2<-32767) left_m2=-32767;
	  /*	   
	  if(flag==0)
	  {
	     left_m2=din;
	  }
	  else if(flag==1)
	  {
	     left_m2=error*;
	  }
      */  
        ////////////////
        
       MCBSP_write16(hMcbsp,left_m2);
        /*  
        ////////////////////////////////////////////////////////////////////////////////
          ee[0]=(float)left_m2;
          ee[0]=ee[0]/32768.0;
          uu[0]=(float)left_m1;
          uu[0]=uu[0]/32768.0;
          
          //Compute yy which is convolution of ww and xx
          yy[0]=0.0;
          for(i=0;i<L;i++)
          {
            yy[0]= yy[0]+ww[i]*uu[i];
          }
          //Compute xxm1 which is convolution of ssh and xx
          xxf[0]=0.0;
          for(i=0;i<L;i++)
          {
            xxf[0]=xxf[0]+ssh[i]*uu[i];
          }  
          //Update coefficients of ww1 using LMS algorithm
          alpha=0.02*ee[0];  
          for(i=0;i<L;i++)
          {
            ww[i]=ww[i]-alpha*xxf[i];
          }
          //delay one Sample
          for(i=L-1;i>0;i--)
          {
            uu[i]=uu[i-1];
            xxf[i]=xxf[i-1];
            ee[i]=ee[i-1];
            yy[i]=yy[i-1];
          } 
          ////////////////////////////////////////////////////////////////////////////////
          temp=yy[0]*32768;
          if(temp>32768) temp=32768;
          else if(temp<-32767) temp=-32767;
          left_y1=(int)temp;

        ////////////////////////////////////////////////////////////////////////////////

        //Write(pMCBSP0->dxr2,left_y1);		// �����ݵ�McBSP0
        //Write(pMCBSP0->dxr1,left_y1);		// ���������AIC23���
        MCBSP_write16(hMcbsp,left_y1);
        */
        count_pro++;
}
void main()
{
	int i;
	int temp;
	i2c_status = 1;
    /* Initialize CSL library - This is REQUIRED !!! */
    /*��ʼ��CSL��*/
    CSL_init();

	PLL_config(&myConfig);
    
    /* Initialize I2C, using parameters in init structure */
    /*��ʼ��I2C�ĸ�ʽ*/

//	I2C_config(&Config);
//	I2C_start();
	
//	I2C_getConfig(&Config1);
	/*I2C is undet reset*/
	I2C_RSET(I2CMDR,0);
	/*����Ԥ��Ƶ�Ĵ���,I2C��mode clock is 10MHz*/
	delay(100);
	I2C_RSET(I2CSAR,0x001A);
	I2C_RSET(I2CMDR,0x0620);
		
    I2C_setup(&I2Cinit);
  	/*���ãɣ��õ�Mater clock*/
	I2C_RSET(I2CCLKL,100);
	I2C_RSET(I2CCLKH,100);

    I2C_getConfig(&testI2C);

hMcbsp = MCBSP_open(MCBSP_PORT1,MCBSP_OPEN_RESET);
	/*����McBSP0*/
	MCBSP_config(hMcbsp,&Mcbsp1Config);
	/*����McBSP0*/
	MCBSP_start(hMcbsp, 
                MCBSP_RCV_START | MCBSP_XMIT_START, 
                0);

    MCBSP_getConfig(hMcbsp,&Mcbsptest);

    /*reset AIC23*/
    i2c_status = I2C_write( reset,          //pointer to data array
	    	                2,				//length of data to be transmitted
	    	                1,				//master or slaver
	    	                CODEC_ADDR,	    //slave address to transmit to
	    	                1,				//transfer mode of operation
	    	                30000			//time out for bus busy
	    		            ); 
	delay(1000);
    /*����AIC23�����־�����*/
    i2c_status = I2C_write( power_down_control,//pointer to data array
	    	                2,				//length of data to be transmitted
	    	                1,				//master or slaver
	    	                CODEC_ADDR,	    //slave address to transmit to
	    	                1,				//transfer mode of operation
	    	                30000			//time out for bus busy
	    		            );            
	/*����AIC23�����ֽӿ�*/
	i2c_status = I2C_write( digital_audio_inteface_format,//pointer to data array
	    	                2,				//length of data to be transmitted
	    	                1,				//master or slaver
	    	                CODEC_ADDR,	    //slave address to transmit to
	    	                1,				//transfer mode of operation
	    	                30000			//time out for bus busy
	    	               	);
	 /*����AIC23ģ��ͨ·*/
/*	i2c_status = I2C_write( analog_aduio_path_control,//pointer to data array
	    	                2,				//length of data to be transmitted
	    	                1,				//master or slaver
	    	                CODEC_ADDR,	    //slave address to transmit to
	    	                1,				//transfer mode of operation
	    	                30000			//time out for bus busy
	    		            );*/
	/*��������ͨ·*/
	i2c_status = I2C_write( digital_audio_path_control,//pointer to data array
	    	                2,				//length of data to be transmitted
	    	                1,				//master or slaver
	    	                CODEC_ADDR,	    //slave address to transmit to
	    	                1,				//transfer mode of operation
	    	                30000			//time out for bus busy
	    	              	);    	
	/*����AIC23�Ĳ�����*/
	i2c_status = I2C_write( sample_rate_control,//pointer to data array
	    	                2,				//length of data to be transmitted
	    	                1,				//master or slaver
	    	                CODEC_ADDR,	    //slave address to transmit to
	    	                1,				//transfer mode of operation
	    	                30000			//time out for bus busy
	    	                );
	/*���ö�������*/
	i2c_status = I2C_write( left_headphone_volume_control,//pointer to data array
	    	                2,				//length of data to be transmitted
	    	                1,				//master or slaver
	    	                CODEC_ADDR,	    //slave address to transmit to
	    	                1,				//transfer mode of operation
	    	                30000			//time out for bus busy
	    	                );
	i2c_status = I2C_write( right_headphone_volume_control,//pointer to data array
	    	                2,				//length of data to be transmitted
	    	                1,				//master or slaver
	    	                CODEC_ADDR,	    //slave address to transmit to
	    	                1,				//transfer mode of operation
	    	                30000			//time out for bus busy
	    	                );  
	/*����Line���������*/
	i2c_status = I2C_write( left_line_input_volume_control,//pointer to data array
	    	                2,				//length of data to be transmitted
	    	                1,				//master or slaver
	    	                CODEC_ADDR,	    //slave address to transmit to
	    	                1,				//transfer mode of operation
	    	                30000			//time out for bus busy
	    	                );
	i2c_status = I2C_write( right_line_input_volume_control,//pointer to data array
	    	                2,				//length of data to be transmitted
	    	                1,				//master or slaver
	    	                CODEC_ADDR,	    //slave address to transmit to
	    	                1,				//transfer mode of operation
	    	                30000			//time out for bus busy
	    	                );
	/*����AIC23*/
	i2c_status = I2C_write( digital_interface_activation,//pointer to data array
	    	   2,				//length of data to be transmitted
	    	   1,				//master or slaver
	    	   CODEC_ADDR,	    //slave address to transmit to
	    	   1,				//transfer mode of operation
	    	   30000			//time out for bus busy
	    	   );
	    	   


    
    //PLL_Init(100);
    wait(29);
    SDRAM_init();     
    /*Data Initialization*/
    TIME_flag=0;  
    count_timer=0;
    count_pro=0;
 
    for(i=0;i<L;i++)
    {
      uu[i]=0.0;
      xxf[i]=0.0;  
      yy[i]=0.0;
      yyh[i]=0.0;
      ee[i]=0.0;      
      ww[i]=0.0;        
      ssh[i]=0.0;     
    } 
    //AIC23_Init();
    //INTR_init( );    
    //TIMER_init( ); 
    /*Main Loop*/
    for(i=0;i<L;i++)
            {
              Pu=0.0;
              uu[i]=0.0;
              xxf[i]=0.0;
              yy[i]=0.0;              
              ee[i]=0.0;
            }
   for(i=0;i<7;i++)                        //��ʼ��
   {
	  data[i]=0;
	  dataf[i]=0.0;
	  wn[i]=0.0;	  
   }    
            
    while(1)
    {
    	FEEDFORWARD_ANC();
    	
    	/*
      if(TIME_flag==1)
      {
        TIME_flag=0;
        
        if(ID_time!=0)
        {        
           IDENTIFICATION();
           ID_time--;            
        }
        
        if(ID_time==0)
        {
        	//ID_time=4000;        
          if(ANC_flag==0)
          {
            ANC_flag=1;
            for(i=0;i<L;i++)
            {
              Pu=0.0;
              uu[i]=0.0;
              xxf[i]=0.0;
              yy[i]=0.0;              
              ee[i]=0.0;
            }
          }
                  while (!MCBSP_rrdy(hMcbsp)){};
        //while (!ReadMask(pMCBSP0 -> spcr2, SPCR2_XRDY));	// �ȴ�McBSP0׼����
        temp=MCBSP_read16(hMcbsp);
        MCBSP_write16(hMcbsp,temp);
          //FEEDFORWARD_ANC();
        }

      }
      */    
    }
}

/****************************************************************/
void interrupt Timer()
{
	TIME_flag=1;
	count_timer++;
}

/****************************************************************/

void wait(unsigned int cycles)
{
    int i;
    for ( i = 0 ; i < cycles ; i++ ){ }
}


void INTR_init( void )
{
   
     PC55XX_MMR pMMR = (PC55XX_MMR)C55XX_MMR_ADDR;   
     Write(pMMR->ivpd,0xd0);    
     Write(pMMR->ivph,0xd0);
     Write(pMMR->ier0,0x10);
     Write(pMMR->dbier0,0x10);
     Write(pMMR->ifr0,0xffff);       
     asm(" BCLR INTM");
}


void TIMER_init(void)
{
    PC55XX_TIMER pTIMER = (PC55XX_TIMER)C55XX_TIM0_ADDR;
    Write(pTIMER->tim,0);       // Timer register
    Write(pTIMER->prd,0xc34f);  // Timer period register
    Write(pTIMER->tcr,0x00E0);  // Timer control register
    Write(pTIMER->prsc,0);      // Timer prescaler register

}
